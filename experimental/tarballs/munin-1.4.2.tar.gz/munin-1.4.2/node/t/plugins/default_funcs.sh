# Functions that do the Right Thing when called.  For use by test plugins.

do_autoconf ()
{
	echo yes
	exit 0
}

