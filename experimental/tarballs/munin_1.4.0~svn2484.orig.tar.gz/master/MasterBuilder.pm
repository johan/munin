package MasterBuilder;

# $Id: MasterBuilder.pm 2431 2009-09-16 10:04:17Z janl $

use base qw(Module::Build);

use lib '../common/lib';

use warnings;
use strict;

1;
