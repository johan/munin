package MasterBuilder;

# $Id: MasterBuilder.pm 2559 2009-10-10 16:08:43Z feiner.tom $

use base qw(Module::Build);

use lib '../common/blib/lib';

use warnings;
use strict;

1;
